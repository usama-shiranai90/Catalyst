<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>

    <link href="../../../Assets/Frameworks/Tailwind/tailwind.css" rel="stylesheet">
    <link href="../../../Assets/Frameworks/fontawesome-free-5.15.4-web/css/all.css" rel="stylesheet">
    <link href="../../../Assets/Stylesheets/Tailwind.css" rel="stylesheet">
    <link href="../../../Assets/Stylesheets/Master.css" rel="stylesheet">
    <script rel="script" src="../../../node_modules/jquery/dist/jquery.min.js"></script>
    <link href="CourseProfileAssets/courseInject.css" rel="stylesheet">
    <script rel="CourseProfileAssets/courseScript.js"></script>
    <link href="CourseProfileAssets/courseProfileStyle.css" rel="stylesheet">

</head>
<body class="min-h-full">
<div class="w-full">
    <header class="bg-white shadow-md">
        <div class="max-w-7xl mx-auto py-2 px-4 sm:px-6 lg:px-8 flex items-center justify-between h-20">
            <h1 class="text-3xl font-bold text-blue-800 flex-grow text-center">Course Profile Creation</h1>

            <!--  Desktop view of top          -->
            <div class="hidden md:block">
                <div class="ml-2 flex items-center md:ml-6">
                    <!-- Profile -->
                    <div class="mr-3 relative">

                        <div class="user-profile-section-desktop">
                            <button type="button" class="max-w-6xl bg-gray-800 rounded-full flex items-center

                            text-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-200 focus:ring-white"
                                    id="user-menu-button" aria-expanded="false" aria-haspopup="true">
                                <span class="sr-only">Open user menu</span>
                                <img class="h-14 w-14 rounded-full"
                                     src="../../../Assets/Images/profilePicAvatar.jpg" alt="">
                            </button>
                        </div>
                        <div class="hidden origin-top-right absolute right-0 mt-2 w-48
                                    rounded-md shadow-lg py-1 bg-white ring-1 ring-black ring-opacity-5 focus:outline-none flex flex-col">
                            <a href="#" class=" px-4 py-2 text-sm text-gray-700">Your Profile</a>
                            <a href="#" class=" px-4 py-2 text-sm text-gray-700">Settings</a>
                            <a href="#" class=" px-4 py-2 text-sm text-gray-700">Sign out</a>
                        </div>
                    </div>
                    <!--                  bg-gray-800 p-1 rounded-full text-gray-400 hover:text-white focus:outline-none
                                            focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-white-->
                    <div class="flex flex-col relative">
                        <p class="text-sm  text-gray-800 text-center">2321321</p>
                        <div class="w-full self-center border-t-2 border-gray-300 " ></div>
                        <p class="text-sm text-gray-800 text-center">Student F18-BCSE-037</p>
                    </div>

                </div>
            </div>
            <!--            Mobile View-->
            <div class="-mr-2 flex md:hidden">
                <!-- Mobile menu button -->
                <button type="button" class="bg-gray-800 inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-white" aria-controls="mobile-menu" aria-expanded="false">
                    <span class="sr-only">Open main menu</span>
                    <!--
                      Heroicon name: outline/menu

                      Menu open: "hidden", Menu closed: "block"
                    -->
                    <svg class="block h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                    </svg>
                    <!--
                      Heroicon name: outline/x

                      Menu open: "block", Menu closed: "hidden"
                    -->
                    <svg class="hidden h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>
        </div>
    </header>
    <main class="">
        <div class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
            <!-- Replace with your content -->
            <div class="px-4 py-6 sm:px-0">

                <!--    top two section-->
                <div class="w-full grid grid-rows-2 gap-3">

                    <div class="middle-section-topic row-span-2">
                        <h2 class="text-3xl" id="subject-topic-ID">Course Profile Creation</h2>
                        <p class="text-sm ">Following data needs to be completed before manipulating student data
                            course.</p>
                    </div>

                    <!--        papa color main-section-->
                    <div class="bg-blue-500 rounded-t-lg border-gray-500 border-opacity-100 border-solid border-1 mt-2">
                        <h2 class="text-2xl text-center" id="subject-topic-ID">Course Profile Creation</h2>

                        <form method="post">
                            <div class="rounded-t-lg bg-white border-solid border-2 flex flex-row
             px-5 pt-4 pb-4">

                                <div class="left-container flex-shrink w-64">


                                    <!--                        course title-->
                                    <div class="textField-label-content w-full" id="courseTitleDivId">
                                        <label for="courseTitle"></label>
                                        <input class="textField" type="text" id="courseTitle" name ="courseTitle">
                                        <label class="textField-label">Course Title</label>
                                    </div>


                                    <!--                        course Code-->
                                    <div class="textField-label-content w-full" id="courseCodeDivId">
                                        <label for="courseCode"></label>
                                        <input class="textField" type="text" id="courseCode" name ="courseCode">
                                        <label class="textField-label">Course Code</label>
                                    </div>


                                    <!--                        credit Hour-->
                                    <div class="textField-label-content w-full" id="creditHourDivId">
                                        <label for="creditHour"></label>
                                        <input class="textField" type="text" id="creditHour" name ="creditHour">
                                        <label class="textField-label">credit Hour</label>
                                    </div>


                                    <!--                        Pre requisite-->
                                    <div class="textField-label-content w-full" id="preRequisiteDivId">
                                        <label for="preRequisite"></label>
                                        <input class="textField" type="text" id="preRequisite" name ="preRequisite">
                                        <label class="textField-label">pre requisite</label>
                                    </div>


                                    <!--                       Term-->
                                    <div class="textField-label-content w-full" id="TermDivId">
                                        <label for="Term"></label>
                                        <input class="textField" type="text" id="Term" name ="Term">
                                        <label class="textField-label">Term</label>
                                    </div>


                                    <!--                       Program level-->
                                    <div class="textField-label-content w-full" id="courseTitleDivId">
                                        <label for="courseTitle"></label>
                                        <input class="textField" type="text" id="ProgramLevel" name ="ProgramLevel">
                                        <label class="textField-label">Program level</label>
                                    </div>


                                    <!--                        program-->
                                    <div class="textField-label-content w-full" id="programDivId">
                                        <label for="program"></label>
                                        <input class="textField" type="text" id="program" name ="program">
                                        <label class="textField-label">program</label>
                                    </div>



                                    <!--                        course effective-->
                                    <div class="textField-label-content w-full" id="courseEffectiveDivId">
                                        <label for="courseEffective"></label>
                                        <input class="textField" type="text" id="courseEffective" name ="courseEffective">
                                        <label class="textField-label">course effective</label>
                                    </div>


                                </div>


                                <div class="right-container">

                                </div>

                        </form>
                    </div>


                </div>
                <!-- /End replace -->
            </div>
    </main>
</div>

</body>
</html>