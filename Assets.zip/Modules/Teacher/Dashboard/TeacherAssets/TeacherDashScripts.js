/*Script would load when the whole page it is associated to is loaded along with its contents*/
// window.onload = function () {


    /*jQuery*/
    $(document).ready(function () {

        //Loading teacher's dashboard
        $("#teacherDashboardID").click(function () {
            $("#teacherMainContent").html("<iframe class='h-full block' src='LoadingTestPage.php' style='width: 100%'></iframe>");
        })
    });
// }
