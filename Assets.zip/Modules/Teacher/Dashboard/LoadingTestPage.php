<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link href="../../../Assets/Stylesheets/Tailwind.css" rel="stylesheet">
    <link href="../../../Assets/Stylesheets/Master.css" rel="stylesheet">
<!--    <link href="" rel="stylesheet">-->
    <link href="Assets/TeacherDashboardStyles.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="Assets/TeacherDashScripts.js" rel="script"></script>
    <script src="../../../Assets/Scripts/Master.js"></script>

</head>

<body>
<!--<script>
    $(document).ready(function () {
        $("#teacherDashboardID").click(function () {
            $.ajax({
                url: "example1.php",
                success: function(result){
                    $("#teacherMainContent").html(result);
                }
            });
        })
    });
</script>
-->
<header class="text-center text-4xl p-2">
    Dashboard
    <div class="profilePictureDiv">
        <div class="flex">
            <img src="../../../Assets/Images/profilePicAvatar.jpg" width="40">
            <div class="flex flex-col text-xs pl-4 pt-1">
                <a href="#">My Full Name</a>
                <hr class="w-full">
                <a href="#">My Full Roll Number</a>
            </div>
        </div>
    </div>
</header>


<div class="wrapper">

    <div class="" style=" border: black 1px solid" id="teacherMainContent">
        Content
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
        <div>
            s
        </div>
    </div>
</div>

</body>
</html>
